package Away.test;

import org.testng.annotations.AfterClass;

public class util {

    public static final String BASE_URL = "https://www.awaytravel.com/";
    public static final  String BASE_URL_REGISTER = "https://www.awaytravel.com/register";
    public static final  String BASE_URL_LOGIN = "https://www.awaytravel.com/";

    public static final  String EMAIL = "mailvaganamvickram@gmail.com";
    public static final  String PASSWORD = "Vicky@123";


}

