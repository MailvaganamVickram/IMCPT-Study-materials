package Away.test;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import static Away.test.util.BASE_URL;
public class AddtoCart {
    WebDriver driver;
@Test
    public  void testCart (){
        setupBrowser();
        ScreenResolution();
        OpenTestSite();
        shopnow();

    }
    public void setupBrowser(){
        ChromeOptions options = new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        options.addArguments("--remote-allow-origins=*");
        WebDriver driver = new ChromeDriver(options);
        System.setProperty("C:/Selenium Driver/ChromeDrivers","webdriver.chrome.driver");
        this.driver = driver;
    }
    public void ScreenResolution(){driver.manage().window().maximize();}

    public void OpenTestSite(){driver.get(BASE_URL);}

    public void shopnow(){
        WebElement shop = driver.findElement
                (By.xpath("//*[@id=\"main-content\"]/div/div[1]/section/div[2]/div/a"));
        shop.click();

        WebElement item = driver.findElement
               (By.xpath("//a[@aria-label='The Carry-On Flex']//div//img[@class='image_component__IJv7W image_loaded__0nQ57']"));
        item.click();

        WebElement addtocart = driver.findElement
                (By.cssSelector("div[class='add-to-cart-mobile buy_box_body_addToCart__R6dMK buy_box_body_addToCartMobile__Wzz0J'] div[class='button_overlay__IUmCY button_secondaryOverlay__GkyBZ']"));
        addtocart.click();

        WebElement viewcart = driver.findElement
                (By.xpath("//*[@id=\"__next\"]/div[2]/div[1]/div[2]/div[1]/button/div"));
        viewcart.click();

        WebElement checkout = driver.findElement
                (By.xpath("//*[@id=\"main-content\"]/div/div[1]/div[2]/div[2]/div/a"));
        checkout.click();

    }
    @AfterClass
    public void CloseBrowser() throws InterruptedException {
        Thread.sleep(5000);
        driver.close();
    }


}
